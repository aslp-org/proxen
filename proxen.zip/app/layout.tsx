import type { Metadata } from 'next';
import Script from 'next/script';
import { siteConfig } from '@/siteConfig';
import '@/styles/index.css';

export const metadata: Metadata = {
  metadataBase: new URL(siteConfig.url),
  title: {
    default: siteConfig.seo.defaultTitle,
    template: `%s${siteConfig.seo.titleTemplate}`,
  },
  description: siteConfig.seo.defaultDescription,
  keywords: [...siteConfig.keywords],
  openGraph: {
    type: 'website',
    siteName: siteConfig.title,
    images: [{ url: siteConfig.seo.defaultImage, width: 1200, height: 630 }],
  },
  twitter: {
    card: 'summary_large_image',
    site: siteConfig.seo.twitterHandle,
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <head>
        {/* Google Fonts preconnect — reduces DNS/handshake latency */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,400&display=swap"
          rel="stylesheet"
        />
        {/* Hero background image preload — tells browser to fetch LCP resource early */}
        <link
          rel="preload"
          as="image"
          href="https://images.prismic.io/proxen/agwq96YofJOwHW1I_Hero-Bg.png?auto=format,compress"
        />
      </head>
      <body>
        {children}
        <Script
          src="https://www.googletagmanager.com/gtag/js?id=G-GD15NGHY95"
          strategy="afterInteractive"
        />
        <Script id="gtag-init" strategy="afterInteractive">
          {`window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','G-GD15NGHY95');`}
        </Script>
      </body>
    </html>
  );
}
